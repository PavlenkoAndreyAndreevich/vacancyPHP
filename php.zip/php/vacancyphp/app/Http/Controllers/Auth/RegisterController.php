<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{

    use RegistersUsers;

    public function __construct()
    {

    }

    protected function register(Request $request)
    {

        $serializedArr = serialize($request['phone']);
         User::create([
            'name' => $request['name'],
            'email' => $request['email'],
            'phone' =>  $serializedArr,
        ]);

        return redirect()->route('home')
        ->with('success', 'You are registered');
    }

    public function checkemail(Request $request)
    {
        $email =$request->input('email');
        $user = User::where('email',$email)->first();
        if($user) return response()->json(true);
        else return response()->json(false);

    }
}
