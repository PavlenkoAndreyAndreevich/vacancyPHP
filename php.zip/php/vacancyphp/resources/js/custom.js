

const form = document.forms.form
const phoneContainer = document.querySelector('.mb-0')
const addPhone = document.querySelector('span.add')
const removePhone = document.querySelector('span.remove')
const token = document.querySelector('meta[name="csrf-token"]').getAttribute('content')
let counter = 0

//Listeners

addPhone.addEventListener('click', ()=>{
    if(counter <= 3 ) {
      phoneContainer.insertAdjacentElement('beforebegin', createPhoneElement())
      counter++
    }
})

form.addEventListener('click', (event)=>{
    if(event.target.classList.contains('fa-minus')){
      event.target.closest('.form-group').remove()
      counter--
    }
})

form.addEventListener('input', (event)=>{
    event.target.nextElementSibling.style.display = 'none'
})

form.addEventListener('submit', submitValidationHandler)

// Functions

function submitValidationHandler(event){

    event.preventDefault()
    let isValid = true
    const inputName = document.querySelector('input[name="name"]').value
    const inputEmail = document.querySelector('input[name="email"]').value
    const regEx = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

    if(inputName.trim().length <= 2){
        document.querySelector('.invalid-feedback').style.display = 'block'
        isValid = false
    }else{
        document.querySelector('.invalid-feedback').style.display = 'none'
    }

    if(inputEmail.trim().match(regEx)){
        document.querySelector('span.email-invalid').style.display = 'none'
    }else{
        document.querySelector('span.email-invalid').style.display = 'block'
        isValid = false
    }

    // Проверка уникальности email
    checkEmailRequest(inputEmail, isValid)
}

function checkEmailRequest(email, isValidFields){

    fetch('/checkemail',{
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json, text-plain, */*",
          "X-Requested-With": "XMLHttpRequest",
          "X-CSRF-TOKEN": token
         },
        method: 'POST',
        body: JSON.stringify({
          email
        })
       })
    .then((response) => {
        return response.json();
      })
    .then(data => {
        if(data){
            document.querySelector('span.email-exist').style.display = 'block'
        }else{
            document.querySelector('span.email-exist').style.display = 'none'
            isValidFields ? form.submit() : null
        }
    })
}

function createPhoneElement(){

    const div = document.createElement('div')
          div.classList.add('form-group', 'row')

    const label = document.createElement('label')
          label.classList.add('col-md-4', 'col-form-label', 'text-md-right')
          label.htmlFor = 'phone'

    const div2 = document.createElement('div')
          div2.classList.add('col-md-6')

    const input = document.createElement('input')
          input.classList.add('form-control')
          input.type = 'number'
          input.id = 'phone'
          input.name = 'phone[]  '

    const span = document.createElement('span')
          span.classList.add('remove')

    const i = document.createElement('i')
          i.classList.add('fas', 'fa-minus')

    span.appendChild(i)
    div. appendChild(label)
    div2.appendChild(input)
    div. appendChild(div2)
    div. appendChild(span)

    return div
}
